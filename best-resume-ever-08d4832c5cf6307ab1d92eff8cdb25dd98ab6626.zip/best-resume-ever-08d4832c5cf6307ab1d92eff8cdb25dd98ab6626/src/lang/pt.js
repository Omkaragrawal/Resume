/* eslint-disable */
const pt = {
  headings: {
    contact: 'Contactos',
    experience: 'Experiência Profissional',
    education: 'Educação',
    skills: 'Competências'
  }
};
export default pt;
