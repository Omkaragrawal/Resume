/* eslint-disable */
const en = {
  headings: {
    contact: 'Contact',
    experience: 'Experience',
    education: 'Education',
    skills: 'Skills'
  }
};
export default en;
