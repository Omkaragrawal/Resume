/* eslint-disable */
const fr = {
  headings: {
    contact: 'Contact',
    experience: 'Expériences professionelles',
    education: 'Formation',
    skills: 'Compétences'
  }
};
export default fr;
