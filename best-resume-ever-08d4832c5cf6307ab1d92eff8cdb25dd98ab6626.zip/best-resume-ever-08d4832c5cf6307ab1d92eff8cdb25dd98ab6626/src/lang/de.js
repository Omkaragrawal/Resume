/* eslint-disable */
const de = {
  headings: {
    contact: 'Kontakt',
    experience: 'Berufserfahrung',
    education: 'Schulbildung',
    skills: 'Qualifikationen'
  }
};
export default de;
